package com.cg.ProductSpringBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ProductSpringBoot.dto.Inventory;
import com.cg.ProductSpringBoot.dto.Product;
import com.cg.ProductSpringBoot.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	@Autowired
	ProductService productservice;
	
	/*@RequestMapping(method=RequestMethod.GET,value="/checkname/{uname}")
	public String getName(@PathVariable("uname")String mname,@RequestParam("prodid")String id) {
		System.out.println("hii");
		return id+"Capgemini"+mname;
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/checkname")
	public String getData(@RequestParam("productid")int pid,@RequestParam("productname")String pname,@RequestParam("productprice")String pprice) {
		System.out.println(pid+" "+pname+" "+pprice);
		return "WelCome";
	}*/
	
	@RequestMapping(value="/add",method= RequestMethod.POST)
	public ResponseEntity<Product> addProduct(@RequestBody Product pro) {
		
		Product prod = productservice.addProduct(pro);
		if(prod == null) {
			return new ResponseEntity("Product Not Added",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Product>(prod,HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/show",method= RequestMethod.GET)
	public ResponseEntity<List<Product>> showAllProduct(){
		List<Product> myList = productservice.showAll();
		if(myList.isEmpty()) {
			return new ResponseEntity("No Product to show",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);
		
	}

	@RequestMapping(value="/search",method= RequestMethod.GET)
	public ResponseEntity<List<Product>> searchAllProduct(@RequestParam("pname")String name){
		List<Product> myList = productservice.search(name);
		if(myList.isEmpty()) {
			return new ResponseEntity("No Product to show",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/searchprice",method= RequestMethod.POST)
	public ResponseEntity<List<Product>> searchPriceProduct(@RequestParam("min")Double min,@RequestParam("max")Double max){
		List<Product> myList = productservice.searchBeteen(min, max);
		if(myList.isEmpty()) {
			return new ResponseEntity("No Product in database",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);
		
	}
	
//	@RequestMapping(value="/addall",method= RequestMethod.POST)
//	public ResponseEntity<Product> addAll(
//			@RequestParam("id")int id,
//			@RequestParam("name")String name,
//			@RequestParam("price")double price,
//			@RequestParam("desc")String desc,
//			@RequestParam("inid")int inid,
//			@RequestParam("inname")String inname
//			){
//		
//		Inventory inventory = new Inventory();
//		inventory.setId(inid);
//		inventory.setName(inname);
//		
//		Product prod = new Product();
//		prod.setId(id);
//		prod.setName(name);
//		prod.setPrice(price);
//		prod.setDescription(desc);
//		prod.setInventory(inventory);
//		
//		Product pro = productservice.addProduct(prod);
//		if(pro==null) {
//			return new ResponseEntity("No Product in database",HttpStatus.NOT_FOUND);
//		}
//		
//		return new ResponseEntity<Product>(prod,HttpStatus.OK);
//		
//	}
	
	@RequestMapping(value="/addall",method= RequestMethod.POST)
	public ResponseEntity<Product> addAll(@ModelAttribute Product prod){
		
//		Inventory inventory = new Inventory();
//		inventory.setId(inid);
//		inventory.setName(inname);
//		
//		Product prod = new Product();
//		prod.setId(id);
//		prod.setName(name);
//		prod.setPrice(price);
//		prod.setDescription(desc);
//		prod.setInventory(inventory);
//		
		Product pro = productservice.addProduct(prod);
		if(pro==null) {
			return new ResponseEntity("No Product in database",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Product>(prod,HttpStatus.OK);
		
	}
	
}
