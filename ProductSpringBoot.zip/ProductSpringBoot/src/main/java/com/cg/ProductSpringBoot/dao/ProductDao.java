package com.cg.ProductSpringBoot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ProductSpringBoot.dto.Product;

public interface ProductDao extends JpaRepository<Product, Integer>{
	
	public List<Product> findByName(String name);
	public List<Product> findByPriceBetween(Double min,Double max);

}
