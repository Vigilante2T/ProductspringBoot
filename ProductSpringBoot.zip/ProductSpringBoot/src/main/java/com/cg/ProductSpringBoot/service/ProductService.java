package com.cg.ProductSpringBoot.service;

import java.util.List;

import com.cg.ProductSpringBoot.dto.Product;

public interface ProductService {
	
	public Product addProduct(Product pro);
	public List<Product> showAll();
	public List<Product> search(String name);
	public List<Product> searchBeteen(Double min,Double max);

}
