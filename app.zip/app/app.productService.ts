import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from './app.product';


@Injectable({
    providedIn:'root'
})
export class ProductService{
    opionts={
        headers: new HttpHeaders({
            'Access-Control-Allow-Headers':'Content-Type',
            'Access-Control-Allow-Methods':'GET,POST,OPTIONS',
            'Access-Control-Allow-oRIGIN':'*'
        })
    }

    constructor(private http:HttpClient){}

        getAllProduct(){
           return this.http.get("http://localhost:9098/product/show");
    }

    addAllProduct(prod:any){
        console.log("product console..."+prod);

        let input  = new FormData();
        
        input.append("id",prod.id);
        input.append("name",prod.name);
        input.append("price",prod.price);
        input.append("description",prod.description);
        input.append("inventory.id",prod.inventoryid);
        input.append("inventory.name",prod.inventoryname);
        
        return this.http.post("http://localhost:9098/product/addall",input);
    }

}