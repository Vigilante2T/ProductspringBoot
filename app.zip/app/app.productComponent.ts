import { Component,OnChanges, OnInit } from '@angular/core';
import { ProductService } from './app.productService';
import { Product } from './app.product';

@Component({
    selector:'prod-app',
    templateUrl: 'app.product.html'
})
export class ProductComponent implements OnInit{

    products:Product[];
    model:any={};
    pro:any={"id":1008,"name":"ASDFFF","price":987.987,"description":"Too Lame","inventory.id":109,"inventory.name":"Lemon"}

    constructor(private proService: ProductService){
        console.log("In product Constructor");
    }

    ngOnInit(){
        console.log("in on init");
        this.proService.getAllProduct().subscribe((data:Product[])=>this.products=data);
        
    }
    addProduct(){
        // console.log(this.model);

        this.proService.addAllProduct(this.model).subscribe((data:any)=>console.log(data));
    }

}